import React from 'react';

function BusPage() {
  return (
    <div>
      <h2>Bus Page</h2>
      {/* Add content for the Bus page */}
    </div>
  );
}

export default BusPage;
