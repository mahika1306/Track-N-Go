import React from 'react';

function OtherVehiclesPage() {
  return (
    <div>
      <h2>Other Vehicles Page</h2>
      {/* Add content for the Other Vehicles page */}
    </div>
  );
}

export default OtherVehiclesPage;
