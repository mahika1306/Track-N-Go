import React from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom
import Header from "../../MyComponents/Header";

function VehicleType() {
  return (
    <>
      <Header />
      <div>
        <h1>Vehicle Types</h1>
        <Link to="/bus">
          <button>Bus</button>
        </Link>
        <Link to="/OtherVehiclesType">
          <button>Other Vehicles</button>
        </Link>
      </div>
    </>
  );
}

export default VehicleType;
