import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, BrowserRouter } from "react-router-dom";
// import "./App.css";
import Home from "./components/Home/Home";
import Login from "./components/Login/Login";
import Signup from "./components/Signup/Signup";
import VehicleType from "./components/VehicleType/VehicleType";
import { auth } from "./firebase";
import Bus from "./components/VehicleType/Bus/bus"
import OtherVehiclesPage from "./components/VehicleType/OtherVehicleType/OtherVehiclesPage";
function App() {
  const [userName, setUserName] = useState("");

  useEffect(() => {
    auth.onAuthStateChanged((user) => {
      if (user) {
        setUserName(user.displayName);
      } else setUserName("");
    });
  }, []);

  return (
    <div className="App">
      { 
        <BrowserRouter>
        <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/VehicleType" element={<VehicleType/>} />
            <Route path="/VehicleType/Bus" element={<Bus/>} />
            <Route path="/VehicleType/OtherVehicleType" element={<OtherVehiclesPage/>} />
            <Route path="/" element={<Home name={userName} />} />
          </Routes>
        </BrowserRouter>
}
    </div>
    
  );
}

export default App;
